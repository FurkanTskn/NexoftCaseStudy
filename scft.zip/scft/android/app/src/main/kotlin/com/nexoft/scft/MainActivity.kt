package com.nexoft.scft

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
