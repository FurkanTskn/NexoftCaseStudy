import 'dart:ui';

Color green = const Color(0xFF008505);
Color blue = const Color(0xFF0075FF);
Color red = const Color(0xFFFF0000);
Color grey = const Color(0xFFBABABA);
Color black = const Color(0xFF000000);
Color pageColor = const Color(0xFFF4F4F4);
Color white = const Color(0xFFFFFFFF);
