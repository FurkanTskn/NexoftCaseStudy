import 'dart:convert';
import 'package:http/http.dart' as http;

class responsePostRequestModel {
  final String id;
  final String firstName;
  final String lastName;
  final String phoneNumber;
  final String profileImageUrl;

  responsePostRequestModel(
      {required this.id,
      required this.firstName,
      required this.lastName,
      required this.phoneNumber,
      required this.profileImageUrl});

  factory responsePostRequestModel.fromJson(Map<String, dynamic> json) {
    return responsePostRequestModel(
      id: json['id'],
      firstName: json['firstName'],
      lastName: json['lastName'],
      phoneNumber: json['phoneNumber'],
      profileImageUrl: json['profileImageUrl'],
    );
  }
}

Future<responsePostRequestModel> createUser(
    String firstName, String lastName, String phoneNumber, String profileImageUrl) async {
  final response = await http.post(
    Uri.parse('http://146.59.52.68:11235/api/User'),
    headers: {
      'ApiKey': 'c40abc66-6a8f-47fc-b36e-2cd490203ce6',
      'Content-type': 'application/json',
    },
    body: jsonEncode(<String, String>{
      "firstName": firstName,
      "lastName": lastName,
      "phoneNumber": phoneNumber,
      "profileImageUrl": profileImageUrl
    }),
  );

  if (response.statusCode == 200) {
    return responsePostRequestModel
        .fromJson(jsonDecode(response.body)['data'] as Map<String, dynamic>);
  } else {
    throw Exception('Failed to create .');
  }
}
