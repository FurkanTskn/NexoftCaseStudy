import 'package:http/http.dart' as http;
import 'dart:convert';

Future updateAccount(String id, String firstName, String lastName, String phoneNumber,
    String profileImageUrl) async {
  final response = await http.put(
    Uri.http("146.59.52.68:11235", "/api/User/$id", {'id': id}),
    headers: {
      'ApiKey': 'c40abc66-6a8f-47fc-b36e-2cd490203ce6',
      'Content-type': 'application/json',
    },
    body: jsonEncode(<String, String>{
      "firstName": firstName,
      "lastName": lastName,
      "phoneNumber": phoneNumber,
      "profileImageUrl": profileImageUrl
    }),
  );

  if (response.statusCode == 200) {
    return jsonDecode(response.body)['data'] as Map<String, dynamic>;
  } else {
    throw Exception('Failed_updateAccount_response .');
  }
}
