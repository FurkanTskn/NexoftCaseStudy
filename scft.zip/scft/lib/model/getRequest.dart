import 'dart:convert';
import 'package:http/http.dart' as http;

import '../controller/uiController.dart';

class responseGetModelClass {
  final String id;
  final String firstName;
  final String lastName;
  final String phoneNumber;
  final String profileImageUrl;

  responseGetModelClass(
      {required this.id,
      required this.firstName,
      required this.lastName,
      required this.phoneNumber,
      required this.profileImageUrl});

  factory responseGetModelClass.fromJson(Map<String, dynamic> json) {
    return responseGetModelClass(
      id: json['id'],
      firstName: json['firstName'],
      lastName: json['lastName'],
      phoneNumber: json['phoneNumber'],
      profileImageUrl: json['profileImageUrl'],
    );
  }
}

Future getUser() async {
  final response = await http.get(
    Uri.http("146.59.52.68:11235", "/api/User", {'skip': '0', 'take': '999'}),
    headers: {
      'ApiKey': 'c40abc66-6a8f-47fc-b36e-2cd490203ce6',
      'Content-type': 'application/json',
    },
  );

  if (response.statusCode == 200) {
    allContacts.value = await jsonDecode(response.body)['data']['users'];
    return jsonDecode(response.body)['data']['users'];
  } else {
    throw Exception('Failed to load user');
  }
}
