import 'dart:convert';
import 'package:http/http.dart' as http;



Future  deleteAccount(String id) async {

  final response = await http.delete(
    Uri.http("146.59.52.68:11235", "/api/User/$id", {  'id': id }),
    headers: {
      'ApiKey':'c40abc66-6a8f-47fc-b36e-2cd490203ce6',
       'Content-type' :'application/json',
    },

  );

  if (response.statusCode == 200) {
    return  jsonDecode(response.body)['data']as Map<String, dynamic>;
  } else {
    throw Exception('Failed_deleted_response .');
  }
}