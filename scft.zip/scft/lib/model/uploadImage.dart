import 'dart:convert';
import 'dart:io';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

Future<String> upLoadImage(String imagePath) async {
  //convert binary image

  var request = http.MultipartRequest(
    'POST',
    Uri.parse('http://146.59.52.68:11235/api/User/UploadImage'),
  );

  /// MultipartFile method
  request.files.add(await http.MultipartFile.fromPath('image', imagePath));
  var streamedResponse = await request.send();
  var response = await http.Response.fromStream(streamedResponse);

  /// MultipartFile method

  if (response.statusCode == 200) {
    return jsonDecode(response.body)['data']['imageUrl'];
  } else {
    throw Exception('Failed to create .');
  }
}
