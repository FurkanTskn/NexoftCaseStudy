import 'package:flutter/material.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:image_picker/image_picker.dart';

import '../constants.dart';

RxBool editable = false.obs;
RxBool isSearching = false.obs;
RxList allContacts = [].obs;
RxList searchResultsContacts = [].obs;

RxString profileImageUrl = "".obs;
RxString firstName = "".obs;
RxString lastName = "".obs;
RxString phoneNumber = "".obs;
RxString id = "".obs;

RxBool isPickedFromMedia = false.obs;

Future<void> searchContacts(String value) async {
  isSearching.value = true;
  searchResultsContacts.value =
      allContacts.where((val) => val["firstName"].toString().contains(value)).toList();
}

Future getImageFromCamera(int type) async {
  PickedFile?  pickedImage = await ImagePicker().getImage(
      source: type == 1 ? ImageSource.camera : ImageSource.gallery,
      maxWidth: 500,/// Görüntü boyutları  azaltılmıştır
      maxHeight: 500,
      imageQuality: 50);/// Görüntü kalitesi %50 azaltılmıştır
  profileImageUrl.value = pickedImage!.path;
  return pickedImage.path;
}




