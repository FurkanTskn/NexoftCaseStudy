import 'package:scft/model/getRequest.dart';
import 'package:scft/view/contacts.dart';
import 'package:scft/view/new_contact.dart';
import 'package:scft/view/profile.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';




void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.leanBack);
    getUser();

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Contacts',
      initialRoute: 'Contacts',
      routes: {
        'Contacts': (context) =>   Listed(),
        'Profile': (context) =>   Profile(),
        'NewContact': (context) =>   NewContact(),
      },


    );
  }
}
