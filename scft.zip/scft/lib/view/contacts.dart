import 'dart:convert';

import 'package:scft/view/profile.dart';
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:google_fonts/google_fonts.dart';

import '../constants.dart';
import '../controller/uiController.dart';
import '../model/getRequest.dart';

TextEditingController searchBarTextController = TextEditingController();

class Listed extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: GestureDetector(
        onTap: () {

          FocusScope.of(context).requestFocus(FocusNode());
        },
        child: Container(
          decoration: BoxDecoration(
            color: Color(0xFFF4F4F4),
          ),
          child: Container(
            padding: EdgeInsets.fromLTRB(30, 30, 30, 10),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 16.5, 0),
                        child: Text(
                          'Contacts',
                          style: GoogleFonts.getFont(
                            'Nunito',
                            fontWeight: FontWeight.w700,
                            fontSize: 24,
                            color: Color(0xFF000000),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 4, 0, 5),
                        child: SizedBox(
                          width: 24,
                          height: 24,
                          child: GestureDetector(
                            child: SvgPicture.asset(
                              'assets/vectors/vector_11_x2.svg',
                            ),
                            onTap: () {
                              Navigator.pushNamed(context, 'NewContact');
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                TextField(
                  controller: searchBarTextController,
                  onChanged: (value) {
                    searchContacts(value);
                  },
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Colors.white,
                    hintStyle: TextStyle(color: Colors.grey, fontSize: 15),
                    prefixIcon: Icon(Icons.search, color: Colors.grey),
                    hintText: 'Search by name ',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(color: Colors.white)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(color: Colors.white)),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(color: Colors.white)),
                    errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(color: Colors.white)),
                    disabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(color: Colors.white)),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Expanded(
                  child: RefreshIndicator(
                    onRefresh: () async {
                      getUser();
                    },
                    color: grey,
                    child: SizedBox(
                        height: MediaQuery.of(context).size.height,
                        child: Obx(
                          () => allContacts.isEmpty
                              ? Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        margin: EdgeInsets.fromLTRB(0, 0, 0, 15),
                                        child: SizedBox(
                                          width: 60,
                                          height: 60,
                                          child: SvgPicture.asset(
                                            'assets/vectors/exclude_4_x2.svg',
                                          ),
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.fromLTRB(0, 0, 1.7, 7),
                                        child: Text(
                                          'No Contacts',
                                          style: GoogleFonts.getFont(
                                            'Nunito',
                                            fontWeight: FontWeight.w700,
                                            fontSize: 24,
                                            color: Color(0xFF000000),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.fromLTRB(0, 0, 0.6, 7),
                                        child: Text(
                                          'Contacts you’ve added will appear here.',
                                          style: GoogleFonts.getFont(
                                            'Nunito',
                                            fontWeight: FontWeight.w700,
                                            fontSize: 16,
                                            color: Color(0xFF000000),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.fromLTRB(0, 0, 0.5, 0),
                                        child: TextButton(
                                          onPressed: () {
                                            Navigator.pushNamed(context, 'NewContact');
                                          },
                                          child: Text(
                                            'Create New Contact',
                                            style: GoogleFonts.getFont(
                                              'Nunito',
                                              fontWeight: FontWeight.w700,
                                              fontSize: 16,
                                              color: blue,
                                            ),
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              : isSearching.value == false
                                  ? ListView.builder(
                                      shrinkWrap: true,
                                      itemCount: allContacts.length,
                                      itemBuilder: (context, index) {
                                        return Column(
                                          children: <Widget>[
                                            GestureDetector(
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: const Color(0xFFFFFFFF),
                                                  borderRadius: BorderRadius.circular(12),
                                                ),
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(20, 13, 0, 13),
                                                  child: Row(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        //color:Colors.amber,
                                                        margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                                                        child: Obx(
                                                          () => (allContacts[index]
                                                                          ['profileImageUrl']
                                                                      .isEmpty ||
                                                                  allContacts[index]
                                                                              ['profileImageUrl']
                                                                          .toString()
                                                                          .contains('http') ==
                                                                      false)
                                                              ? SizedBox(
                                                                  height: 34,
                                                                  width: 34,
                                                                  child: SvgPicture.asset(
                                                                    'assets/vectors/exclude_1_x2.svg',
                                                                  ),
                                                                )
                                                              : SizedBox(
                                                                  height: 34,
                                                                  width: 34,
                                                                  child: CircleAvatar(
                                                                    radius: 30.0,
                                                                    backgroundImage: NetworkImage(
                                                                        allContacts[index]
                                                                            ['profileImageUrl']),
                                                                    backgroundColor:
                                                                        Colors.transparent,
                                                                  ),
                                                                ),
                                                        ),
                                                      ),
                                                      Column(
                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin:
                                                                EdgeInsets.fromLTRB(20, 0, 10, 0),
                                                            child: Obx(
                                                              () => Text(
                                                                allContacts[index]['firstName'],
                                                                style: GoogleFonts.getFont(
                                                                  'Nunito',
                                                                  fontWeight: FontWeight.w700,
                                                                  fontSize: 16,
                                                                  color: Color(0xFF000000),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin:
                                                                EdgeInsets.fromLTRB(20, 0, 10, 0),
                                                            child: Text(
                                                              allContacts[index]['phoneNumber'],
                                                              style: GoogleFonts.getFont(
                                                                'Nunito',
                                                                fontWeight: FontWeight.w700,
                                                                fontSize: 16,
                                                                color: Color(0xFFBABABA),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              onTap: () {
                                                firstNameTextController.text =
                                                    allContacts[index]['firstName'];
                                                lastNameTextController.text =
                                                    allContacts[index]['lastName'];
                                                phoneNumberTextController.text =
                                                    allContacts[index]['phoneNumber'];
                                                profileImageUrl.value =
                                                    allContacts[index]['profileImageUrl'];

                                                firstName.value = allContacts[index]['firstName'];
                                                lastName.value = allContacts[index]['lastName'];
                                                phoneNumber.value =
                                                    allContacts[index]['phoneNumber'];
                                                id.value = allContacts[index]['id'];

                                                Navigator.pushNamed(
                                                  context,
                                                  'Profile',
                                                );
                                              },
                                            ),
                                            SizedBox(
                                              height: 5,
                                            )
                                          ],
                                        );
                                      },
                                    )
                                  : ListView.builder(
                                      shrinkWrap: true,
                                      itemCount: searchResultsContacts.length,
                                      itemBuilder: (context, index) {
                                        return Column(
                                          children: <Widget>[
                                            GestureDetector(
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  color: const Color(0xFFFFFFFF),
                                                  borderRadius: BorderRadius.circular(12),
                                                ),
                                                child: Container(
                                                  padding: EdgeInsets.fromLTRB(20, 13, 0, 13),
                                                  child: Row(
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        //color:Colors.amber,
                                                        margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                                                        child: Obx(
                                                          () => (searchResultsContacts[index]
                                                                          ['profileImageUrl']
                                                                      .isEmpty ||
                                                                  searchResultsContacts[index]
                                                                              ['profileImageUrl']
                                                                          .toString()
                                                                          .contains('http') ==
                                                                      false)
                                                              ? SizedBox(
                                                                  height: 34,
                                                                  width: 34,
                                                                  child: SvgPicture.asset(
                                                                    'assets/vectors/exclude_1_x2.svg',
                                                                  ),
                                                                )
                                                              : SizedBox(
                                                                  height: 34,
                                                                  width: 34,
                                                                  child: CircleAvatar(
                                                                    radius: 30.0,
                                                                    backgroundImage: NetworkImage(
                                                                        searchResultsContacts[index]
                                                                            ['profileImageUrl']),
                                                                    backgroundColor:
                                                                        Colors.transparent,
                                                                  ),
                                                                ),
                                                        ),
                                                      ),
                                                      Column(
                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            margin:
                                                                EdgeInsets.fromLTRB(20, 0, 10, 0),
                                                            child: Text(
                                                              searchResultsContacts[index]
                                                                  ['firstName'],
                                                              style: GoogleFonts.getFont(
                                                                'Nunito',
                                                                fontWeight: FontWeight.w700,
                                                                fontSize: 16,
                                                                color: Color(0xFF000000),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            margin:
                                                                EdgeInsets.fromLTRB(20, 0, 10, 0),
                                                            child: Text(
                                                              searchResultsContacts[index]
                                                                  ['phoneNumber'],
                                                              style: GoogleFonts.getFont(
                                                                'Nunito',
                                                                fontWeight: FontWeight.w700,
                                                                fontSize: 16,
                                                                color: Color(0xFFBABABA),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              onTap: () {
                                                firstNameTextController.text =
                                                    searchResultsContacts[index]['firstName'];
                                                lastNameTextController.text =
                                                    searchResultsContacts[index]['lastName'];
                                                phoneNumberTextController.text =
                                                    searchResultsContacts[index]['phoneNumber'];
                                                profileImageUrl.value =
                                                    searchResultsContacts[index]['profileImageUrl'];

                                                firstName.value =
                                                    searchResultsContacts[index]['firstName'];
                                                lastName.value =
                                                    searchResultsContacts[index]['lastName'];
                                                phoneNumber.value =
                                                    searchResultsContacts[index]['phoneNumber'];
                                                id.value = searchResultsContacts[index]['id'];
                                                Navigator.pushNamed(context, 'Profile');
                                              },
                                            ),
                                            SizedBox(
                                              height: 5,
                                            )
                                          ],
                                        );
                                      },
                                    ),
                        )),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
