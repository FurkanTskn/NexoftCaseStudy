


import 'package:flutter/cupertino.dart';

Widget seperatorWidget =    Container(
  margin: const EdgeInsets.fromLTRB(0, 0, 0, 14),
  child: Container(
    decoration: const BoxDecoration(
      color: Color(0xFFBABABA),
    ),
    child: Container(
      width: 400,
      height: 1,
    ),
  ),
);