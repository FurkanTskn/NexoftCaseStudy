import 'dart:io';
import 'dart:typed_data';

import 'package:scft/view/profile.dart';
import 'package:scft/view/widgets/textFieid.dart';
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:google_fonts/google_fonts.dart';

import '../constants.dart';
import '../controller/uiController.dart';
import '../model/getRequest.dart';
import '../model/postRequest.dart';
import '../model/uploadImage.dart';

RxString pickedImagePath=''.obs;

final newfirstNameTextController =  TextEditingController()  ;
final newlastNameTextController = TextEditingController();
final newphoneNumberTextController = TextEditingController();

final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();




class NewContact extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    final snackBarUserAdded = SnackBar(
      elevation: 20,
      content:Row(
        children: [
          Icon(Icons.verified_rounded,
            color: green,),
          Text('User added !',
            style: TextStyle(color:green,),),
        ],
      ),

      behavior: SnackBarBehavior.fixed,
      shape:   const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(15),
          topRight: Radius.circular(15),
        ),
      ),
      backgroundColor: white,
    );
    Future<void> createNewUser() async {
      String photoUrlForCreateUser;
      if(pickedImagePath.isNotEmpty){
        photoUrlForCreateUser = await upLoadImage(pickedImagePath.toString().replaceAll('[', '').replaceAll(']', ''));
      }
      else{
        photoUrlForCreateUser = "";
      }

      await createUser(
      newfirstNameTextController.text,
      newlastNameTextController.text,
      newphoneNumberTextController.text,
      photoUrlForCreateUser);


      getUser();

    }

    return 
    Scaffold(
      resizeToAvoidBottomInset : false,
      body: Container(
        decoration: const BoxDecoration(
          color: Color(0xFFF4F4F4),
        ),
        child: Container(
          padding: EdgeInsets.fromLTRB(0, 50, 0, 0),
          child: Container(
            decoration: const BoxDecoration(
              color: Color(0xFFFFFFFF),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(25),
                topRight: Radius.circular(25),
              ),
              boxShadow: [
                BoxShadow(
                  color: Color(0x40000000),
                  offset: Offset(0, -6),
                  blurRadius: 20.0499992371,
                ),
              ],
            ),
            child: SizedBox(
              width: double.infinity,
              child: Container(
                padding: EdgeInsets.fromLTRB(30, 30, 29.6, 30),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          TextButton(
                            child: Text(
                              'Cancel',
                              style: GoogleFonts.getFont(
                                'Nunito',
                                fontWeight: FontWeight.w500,
                                fontSize: 16,
                                color: Color(0xFF0075FF),
                              ),
                            ),
                            onPressed: (){
                            Navigator.of(context).pop();
                          },
                          ),
                          Text(
                            'New Contact',
                            style: GoogleFonts.getFont(
                              'Nunito',
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                              color: Color(0xFF181818),
                            ),
                          ),
                          TextButton(
                            child: Text(
                              'Done',
                              style: GoogleFonts.getFont(
                                'Nunito',
                                fontWeight: FontWeight.w500,
                                fontSize: 16,
                                color: Color(0xFF0075FF),
                              ),
                            ),
                            onPressed: () async {

                              createNewUser();
                              ScaffoldMessenger.of(context).showSnackBar(snackBarUserAdded);
                              Navigator.of(context).pop();



                            },
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(1.6, 0, 0, 14.5),
                      child: SizedBox(
                        width: 195,
                        height: 195,
                        child:
                        Obx(()=> pickedImagePath.value.isEmpty ?

                        SvgPicture.asset(
                          'assets/vectors/exclude_1_x2.svg',
                        )
                        :
                        CircleAvatar(
                            radius: 30.0,
                            backgroundImage: FileImage( File(pickedImagePath.value)) ,
                            backgroundColor: Colors.transparent,
                          ),
                        )


                      ),
                    ),
                    Center(
                      child: Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0.9, 20),
                        child: TextButton(
                            child: Text(
                              'Add Photo',
                              style: GoogleFonts.getFont(
                                'Nunito',
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                                color: Color(0xFF181818),
                              ),
                            ),
                            onPressed: () async {
                              showModalBottomSheet<void>(
                                isDismissible: true,
                                context: context,
                                backgroundColor: Colors.white,
                                shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
                                ),
                                builder: (BuildContext context) {
                                  return Container(
                                    height: 200,
                                    child: Center(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.min,
                                        children: <Widget>[
                                          Expanded(
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  child: Padding(
                                                    padding: const EdgeInsets.all(8.0),
                                                    child: ElevatedButton(
                                                      style: ElevatedButton.styleFrom(
                                                          backgroundColor: Color(0xFFF4F4F4),
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.circular(
                                                                10), // <-- Radius
                                                          )),
                                                      onPressed: () async {
                                                          pickedImagePath.value  = await getImageFromCamera(1);

                                                      },
                                                      child: Padding(
                                                        padding: const EdgeInsets.all(8.0),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                          MainAxisAlignment.center,
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment.start,
                                                          children: [
                                                            Container(
                                                              margin:
                                                              EdgeInsets.fromLTRB(0, 4, 0, 5),
                                                              child: SizedBox(
                                                                width: 24,
                                                                height: 24,
                                                                child: SvgPicture.asset(
                                                                  'assets/vectors/camera_31_x2.svg',
                                                                ),
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              width: 15,
                                                            ),
                                                            Text(
                                                              'Camera',
                                                              style: GoogleFonts.getFont(
                                                                'Nunito',
                                                                fontWeight: FontWeight.w700,
                                                                fontSize: 20,
                                                                color: Color(0xFF000000),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  child: Padding(
                                                    padding: const EdgeInsets.all(8.0),
                                                    child: ElevatedButton(
                                                      style: ElevatedButton.styleFrom(
                                                          backgroundColor: Color(0xFFF4F4F4),
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.circular(
                                                                10), // <-- Radius
                                                          )),
                                                      onPressed: () async{
                                                        pickedImagePath.value  =  await getImageFromCamera(0);
                                                      },
                                                      child: Padding(
                                                        padding: const EdgeInsets.all(8.0),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                          MainAxisAlignment.center,
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment.start,
                                                          children: [
                                                            Container(
                                                              margin:
                                                              EdgeInsets.fromLTRB(0, 4, 0, 5),
                                                              child: SizedBox(
                                                                width: 24,
                                                                height: 24,
                                                                child: SvgPicture.asset(
                                                                  'assets/vectors/picture_11_x2.svg',
                                                                ),
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              width: 15,
                                                            ),
                                                            Text(
                                                              'Gallery',
                                                              style: GoogleFonts.getFont(
                                                                'Nunito',
                                                                fontWeight: FontWeight.w700,
                                                                fontSize: 20,
                                                                color: Color(0xFF000000),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  child: Padding(
                                                    padding: const EdgeInsets.all(8.0),
                                                    child: ElevatedButton(
                                                      style: ElevatedButton.styleFrom(
                                                          backgroundColor: Color(0xFFF4F4F4),
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius.circular(
                                                                10), // <-- Radius
                                                          )),
                                                      onPressed: () => Navigator.pop(context),
                                                      child: Text(
                                                        'Cancel',
                                                        style: GoogleFonts.getFont(
                                                          'Nunito',
                                                          fontWeight: FontWeight.w700,
                                                          fontSize: 20,
                                                          color: Color(0xFF0075FF),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              );
                             }),
                      ),
                    ),
                    textFieldGetInfo( hint: "First name", text: "", textController: newfirstNameTextController,),
                    textFieldGetInfo( hint: "Last name", text: "",textController: newlastNameTextController,),
                    textFieldGetInfo( hint: "Phone number", text: "",textController: newphoneNumberTextController,),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}