
import 'dart:io';

import 'package:scft/view/widgets/seperator.dart';
import 'package:scft/view/widgets/textFieid.dart';
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:google_fonts/google_fonts.dart';

import '../constants.dart';
import '../controller/uiController.dart';
import '../model/deleteAccount.dart';
import '../model/getRequest.dart';
import '../model/postRequest.dart';
import '../model/putRequest.dart';
import '../model/uploadImage.dart';

final firstNameTextController =  TextEditingController()  ;
final lastNameTextController = TextEditingController();
final phoneNumberTextController = TextEditingController();

Future<void> updateUserAccount() async {
  firstName.value = firstNameTextController.text ;
  lastName.value = lastNameTextController.text ;
  phoneNumber.value = phoneNumberTextController.text ;

  editable.value = false;
  if(isPickedFromMedia.value){
    String photoUrlForUpdateUser = await upLoadImage(profileImageUrl.value.toString().replaceAll('[', '').replaceAll(']', ''));
    updateAccount(
        id.value,
        firstNameTextController.text,
        lastNameTextController.text,
        phoneNumberTextController.text,
        photoUrlForUpdateUser);
  }
  else{
    updateAccount(
        id.value,
        firstNameTextController.text,
        lastNameTextController.text,
        phoneNumberTextController.text,
        profileImageUrl.value);
  }
  getUser();

}

class Profile extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    final snackBarDeleteAccount = SnackBar(
      elevation: 20,
      content:Row(
        children: [
          Icon(Icons.verified_rounded,
            color: green,),
          Text('Account deleted !',
            style: TextStyle(color:green,),),
        ],
      ),

      behavior: SnackBarBehavior.fixed,
      shape:   const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(15),
          topRight: Radius.circular(15),
        ),
      ),
      backgroundColor: white,
    );
    final snackBarUserChangeApplied = SnackBar(
      elevation: 20,
      content:Row(
        children: [
          Icon(Icons.verified_rounded,
            color: green,),
          Text('Changes has been applied !',
            style: TextStyle(color:green,),),
        ],
      ),

      behavior: SnackBarBehavior.fixed,
      shape:   const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(15),
          topRight: Radius.circular(15),
        ),
      ),
      backgroundColor: white,
    );


    return SafeArea(
      child: Scaffold( resizeToAvoidBottomInset : false,
        body: Container(
          decoration: const BoxDecoration(
            color: Color(0xFFF4F4F4),
          ),
          child: Container(
            padding: EdgeInsets.fromLTRB(0, 50, 0, 0),
            child: Container(
              decoration: const BoxDecoration(
                color: Color(0xFFFFFFFF),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(25),
                  topRight: Radius.circular(25),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x40000000),
                    offset: Offset(0, -6),
                    blurRadius: 20.0499992371,
                  ),
                ],
              ),
              child: SizedBox(
                width: double.infinity,
                child: Container(
                  padding: EdgeInsets.fromLTRB(15, 30, 15, 20),
                  child:  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 24.7, 5),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                                 editable.value = false;
                              },
                              child: Text(
                                'Cancel',
                                style: GoogleFonts.getFont(
                                  'Nunito',
                                  fontWeight: FontWeight.w500,
                                  fontSize: 16,
                                  color: Color(0xFF0075FF),
                                ),
                              ),
                            ),
                            Obx(()=> editable.value ==false ?
                            TextButton(
                                onPressed: () {
                                  editable.value =  true;
                                },
                                child: Text(
                                  'Edit',
                                  style: GoogleFonts.getFont(
                                    'Nunito',
                                    fontWeight: FontWeight.w700,
                                    fontSize: 16,
                                    color: Color(0xFF0075FF),
                                  ),
                                ),
                              )
                              :
                            TextButton(
                              onPressed: () async {
                                updateUserAccount();
                                ScaffoldMessenger.of(context).showSnackBar(snackBarUserChangeApplied);

                              },
                              child: Text(
                                'Done',
                                style: GoogleFonts.getFont(
                                  'Nunito',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                  color: Color(0xFF0075FF),
                                ),
                              ),
                            )
                              ,
                            ),
                          ],
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(2.5, 0, 0, 14.5),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            decoration: BoxDecoration(
                              color: Color(0xFFBABABA),
                              borderRadius: BorderRadius.circular(97.5),
                            ),
                            child: GestureDetector(
                              onTap: (){
                                if(editable.value){
                                  showModalBottomSheet<void>(
                                    isDismissible: true,
                                    context: context,
                                    backgroundColor: Colors.white,
                                    shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.vertical(
                                          top: Radius.circular(25.0)),
                                    ),
                                    builder: (BuildContext context) {
                                      return Container(
                                        height: 200,
                                        child: Center(
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            mainAxisSize: MainAxisSize.min,
                                            children: <Widget>[
                                              Expanded(
                                                child: Row(
                                                  children: [
                                                    Expanded(
                                                      child: Padding(
                                                        padding: const EdgeInsets.all(8.0),
                                                        child: ElevatedButton(
                                                          style: ElevatedButton.styleFrom(
                                                              backgroundColor: Color(0xFFF4F4F4),
                                                              shape: RoundedRectangleBorder(
                                                                borderRadius: BorderRadius.circular(
                                                                    10), // <-- Radius
                                                              )),
                                                          onPressed: () async {
                                                            profileImageUrl.value  = await getImageFromCamera(1);
                                                            isPickedFromMedia.value =true;
                                                           },
                                                          child: Padding(
                                                            padding: const EdgeInsets.all(8.0),
                                                            child: Row(
                                                              mainAxisAlignment:
                                                              MainAxisAlignment.center,
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment.start,
                                                              children: [
                                                                Container(
                                                                  margin:
                                                                  EdgeInsets.fromLTRB(0, 4, 0, 5),
                                                                  child: SizedBox(
                                                                    width: 24,
                                                                    height: 24,
                                                                    child: SvgPicture.asset(
                                                                      'assets/vectors/camera_31_x2.svg',
                                                                    ),
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 15,
                                                                ),
                                                                Text(
                                                                  'Camera',
                                                                  style: GoogleFonts.getFont(
                                                                    'Nunito',
                                                                    fontWeight: FontWeight.w700,
                                                                    fontSize: 20,
                                                                    color: Color(0xFF000000),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Expanded(
                                                child: Row(
                                                  children: [
                                                    Expanded(
                                                      child: Padding(
                                                        padding: const EdgeInsets.all(8.0),
                                                        child: ElevatedButton(
                                                          style: ElevatedButton.styleFrom(
                                                              backgroundColor: Color(0xFFF4F4F4),
                                                              shape: RoundedRectangleBorder(
                                                                borderRadius: BorderRadius.circular(
                                                                    10), // <-- Radius
                                                              )),
                                                          onPressed: ()  async {
                                                            profileImageUrl.value = await getImageFromCamera(0);
                                                          },
                                                          child: Padding(
                                                            padding: const EdgeInsets.all(8.0),
                                                            child: Row(
                                                              mainAxisAlignment:
                                                              MainAxisAlignment.center,
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment.start,
                                                              children: [
                                                                Container(
                                                                  margin:
                                                                  EdgeInsets.fromLTRB(0, 4, 0, 5),
                                                                  child: SizedBox(
                                                                    width: 24,
                                                                    height: 24,
                                                                    child: SvgPicture.asset(
                                                                      'assets/vectors/picture_11_x2.svg',
                                                                    ),
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 15,
                                                                ),
                                                                Text(
                                                                  'Gallery',
                                                                  style: GoogleFonts.getFont(
                                                                    'Nunito',
                                                                    fontWeight: FontWeight.w700,
                                                                    fontSize: 20,
                                                                    color: Color(0xFF000000),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Expanded(
                                                child: Row(
                                                  children: [
                                                    Expanded(
                                                      child: Padding(
                                                        padding: const EdgeInsets.all(8.0),
                                                        child: ElevatedButton(
                                                          style: ElevatedButton.styleFrom(
                                                              backgroundColor: Color(0xFFF4F4F4),
                                                              shape: RoundedRectangleBorder(
                                                                borderRadius: BorderRadius.circular(
                                                                    10), // <-- Radius
                                                              )),
                                                          onPressed: () => Navigator.pop(context),
                                                          child: Text(
                                                            'Cancel',
                                                            style: GoogleFonts.getFont(
                                                              'Nunito',
                                                              fontWeight: FontWeight.w700,
                                                              fontSize: 20,
                                                              color: Color(0xFF0075FF),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  );
                                }
                              },
                              child: Container(
                                width: 195.5,
                                height: 195.5,
                                padding: EdgeInsets.fromLTRB(0.5, 0, 0, 0.5),
                                child:Obx(
                                        ()=>
                                   ( isPickedFromMedia.value== false && profileImageUrl.toString().contains('http') ) ?
                                        Container(
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(97.5),
                                            image:DecorationImage(
                                              fit: BoxFit.cover,
                                              image:NetworkImage(profileImageUrl.value),),
                                          ),
                                        )
                                    :
                                    isPickedFromMedia.value && profileImageUrl.toString().contains('http') == false?
                                    CircleAvatar(
                                      radius: 60.0,
                                      backgroundImage: FileImage( File(profileImageUrl.value)) ,
                                      backgroundColor: Colors.transparent,
                                    )
                                        :
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(97.5),
                                      ),
                                      child: SvgPicture.asset(color:pageColor,
                                        'assets/vectors/exclude_4_x2.svg',
                                      ),
                                    )
                                )

                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0.8, 30),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: TextButton(
                              child: Text(
                                'Change Photo',
                                style: GoogleFonts.getFont(
                                  'Nunito',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                  color: Color(0xFF181818),
                                ),
                              ),
                              onPressed: () async {
                                if(editable.value) {
                                  showModalBottomSheet<void>(
                                    isDismissible: true,
                                    context: context,
                                    backgroundColor: Colors.white,
                                    shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.vertical(
                                          top: Radius.circular(25.0)),
                                    ),
                                    builder: (BuildContext context) {
                                      return Container(
                                        height: 200,
                                        child: Center(
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            mainAxisSize: MainAxisSize.min,
                                            children: <Widget>[
                                              Expanded(
                                                child: Row(
                                                  children: [
                                                    Expanded(
                                                      child: Padding(
                                                        padding: const EdgeInsets.all(8.0),
                                                        child: ElevatedButton(
                                                          style: ElevatedButton.styleFrom(
                                                              backgroundColor: Color(0xFFF4F4F4),
                                                              shape: RoundedRectangleBorder(
                                                                borderRadius: BorderRadius.circular(
                                                                    10), // <-- Radius
                                                              )),
                                                          onPressed: () async {
                                                            profileImageUrl.value = await getImageFromCamera(1);
                                                            isPickedFromMedia.value =true;
                                                          },
                                                          child: Padding(
                                                            padding: const EdgeInsets.all(8.0),
                                                            child: Row(
                                                              mainAxisAlignment:
                                                              MainAxisAlignment.center,
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment.start,
                                                              children: [
                                                                Container(
                                                                  margin:
                                                                  EdgeInsets.fromLTRB(0, 4, 0, 5),
                                                                  child: SizedBox(
                                                                    width: 24,
                                                                    height: 24,
                                                                    child: SvgPicture.asset(
                                                                      'assets/vectors/camera_31_x2.svg',
                                                                    ),
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 15,
                                                                ),
                                                                Text(
                                                                  'Camera',
                                                                  style: GoogleFonts.getFont(
                                                                    'Nunito',
                                                                    fontWeight: FontWeight.w700,
                                                                    fontSize: 20,
                                                                    color: Color(0xFF000000),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Expanded(
                                                child: Row(
                                                  children: [
                                                    Expanded(
                                                      child: Padding(
                                                        padding: const EdgeInsets.all(8.0),
                                                        child: ElevatedButton(
                                                          style: ElevatedButton.styleFrom(
                                                              backgroundColor: Color(0xFFF4F4F4),
                                                              shape: RoundedRectangleBorder(
                                                                borderRadius: BorderRadius.circular(
                                                                    10), // <-- Radius
                                                              )),
                                                          onPressed: ()async{
                                                            profileImageUrl.value = await getImageFromCamera(0);
                                                          },
                                                          child: Padding(
                                                            padding: const EdgeInsets.all(8.0),
                                                            child: Row(
                                                              mainAxisAlignment:
                                                              MainAxisAlignment.center,
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment.start,
                                                              children: [
                                                                Container(
                                                                  margin:
                                                                  EdgeInsets.fromLTRB(0, 4, 0, 5),
                                                                  child: SizedBox(
                                                                    width: 24,
                                                                    height: 24,
                                                                    child: SvgPicture.asset(
                                                                      'assets/vectors/picture_11_x2.svg',
                                                                    ),
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 15,
                                                                ),
                                                                Text(
                                                                  'Gallery',
                                                                  style: GoogleFonts.getFont(
                                                                    'Nunito',
                                                                    fontWeight: FontWeight.w700,
                                                                    fontSize: 20,
                                                                    color: Color(0xFF000000),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Expanded(
                                                child: Row(
                                                  children: [
                                                    Expanded(
                                                      child: Padding(
                                                        padding: const EdgeInsets.all(8.0),
                                                        child: ElevatedButton(
                                                          style: ElevatedButton.styleFrom(
                                                              backgroundColor: Color(0xFFF4F4F4),
                                                              shape: RoundedRectangleBorder(
                                                                borderRadius: BorderRadius.circular(
                                                                    10), // <-- Radius
                                                              )),
                                                          onPressed: () => Navigator.pop(context),
                                                          child: Text(
                                                            'Cancel',
                                                            style: GoogleFonts.getFont(
                                                              'Nunito',
                                                              fontWeight: FontWeight.w700,
                                                              fontSize: 20,
                                                              color: Color(0xFF0075FF),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  );

                                }
                              }),
                        ),
                      ),
                      Obx(()=>
                      editable.value == false ?
                         Column(
                           mainAxisAlignment: MainAxisAlignment.start,
                           crossAxisAlignment: CrossAxisAlignment.start,
                           children: [
                        Container(
                          margin: EdgeInsets.fromLTRB(15, 0, 15, 15),
                          child: Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              firstName.value,
                              style: GoogleFonts.getFont(
                                'Nunito',
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                                color: Color(0xFF181818),
                              ),
                            ),
                          ),
                        ),
                        seperatorWidget,
                        Container(
                          margin: EdgeInsets.fromLTRB(15, 0, 15, 15),
                          child: Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              lastName.value,
                              style: GoogleFonts.getFont(
                                'Nunito',
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                                color: Color(0xFF181818),
                              ),
                            ),
                          ),
                        ),
                        seperatorWidget,
                        Container(
                          margin: EdgeInsets.fromLTRB(15, 0, 15, 15),
                          child: Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              phoneNumber.value,
                              style: GoogleFonts.getFont(
                                'Nunito',
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                                color: Color(0xFF181818),
                              ),
                            ),
                          ),
                        ),
                        seperatorWidget,
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 0),
                          child: TextButton(
                            onPressed: () {
                              showModalBottomSheet<void>(
                                isDismissible: true,
                                context: context,
                                backgroundColor: Colors.white,
                                shape: const RoundedRectangleBorder(
                                  borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
                                ),
                                builder: (BuildContext context) {
                                  return SizedBox(
                                    height: 240,
                                    child: Center(
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          // mainAxisSize: MainAxisSize.max,
                                          children: <Widget>[
                                            const Text(
                                              'Delete Account?',
                                              style: TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 20,
                                                  color: Color(0xFFFF0000)),
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.all(10.0),
                                              child: Column(
                                                children: [
                                                  Row(
                                                    children: [
                                                      Expanded(
                                                        child: Padding(
                                                          padding: const EdgeInsets.only(
                                                              left: 15.0, right: 15),
                                                          child: ElevatedButton(
                                                            style: ElevatedButton.styleFrom(
                                                                backgroundColor: Color(0xFFF4F4F4),
                                                                shape: RoundedRectangleBorder(
                                                                  borderRadius: BorderRadius.circular(
                                                                      10), // <-- Radius
                                                                )),
                                                            child: const Text('Yes',
                                                                style: TextStyle(
                                                                    fontWeight: FontWeight.w400,
                                                                    fontSize: 20,
                                                                    color: Colors.black)),
                                                            onPressed: () {
                                                              deleteAccount(id.value);
                                                              ScaffoldMessenger.of(context).showSnackBar(snackBarDeleteAccount);
                                                              Navigator.pop(context);
                                                              Navigator.pop(context);
                                                              getUser();

                                                                    },
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  Row(
                                                    children: [
                                                      Expanded(
                                                        child: Padding(
                                                          padding: const EdgeInsets.only(
                                                              left: 15.0, right: 15),
                                                          child: ElevatedButton(
                                                            style: ElevatedButton.styleFrom(
                                                                backgroundColor: Color(0xFFF4F4F4),
                                                                shape: RoundedRectangleBorder(
                                                                  borderRadius: BorderRadius.circular(
                                                                      10), // <-- Radius
                                                                )),
                                                            child: const Text('No',
                                                                style: TextStyle(
                                                                    fontWeight: FontWeight.w400,
                                                                    fontSize: 20,
                                                                    color: Colors.black)),
                                                            onPressed: () {
                                                              Navigator.pop(context);

                                                            },
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              );

                            },
                            child: Text(
                              'Delete contact',
                              style: GoogleFonts.getFont(
                                'Nunito',
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                                color:red,
                              ),
                            ),
                          ),
                        ),
                      ],):
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                            textFieldGetInfo( hint: "First name", text: "", textController: firstNameTextController,),
                            textFieldGetInfo( hint: "Last name", text: "",textController: lastNameTextController,),
                            textFieldGetInfo( hint: "Phone number", text: "",textController: phoneNumberTextController,),
                          ],)



                      ),

                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
